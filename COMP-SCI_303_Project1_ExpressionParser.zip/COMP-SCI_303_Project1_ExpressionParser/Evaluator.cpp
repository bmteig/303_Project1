#include "Evaluator.h"
Evaluator::Evaluator() {}
Evaluator::~Evaluator() {}

int Evaluator::eval(string exp) {

	//Lauren's Code - function below
	if (errorCheck(exp) == 1) {
		return 1;
	}
	//Ben's Code
	while (!terms.empty()) {								//verifies that terms stack is empty for each new expression
		terms.pop();
	}
	expression = removeSpaces(exp);							//removes spaces from given string for clean parsing

	for (int i = 0; i < expression.length(); i++) {
		if (isdigit(expression[i])) {
			terms.push(expression[i] - '0');				//push all number values to the terms stack
		}
		else if (expression[i] == '('){
			ops.push(expression[i]);						//push all open parenthesis to the operands stack
		}
		else if (expression[i] == ')') {				//when closed parenethesis found, evaluate everything before until open parenthesis
			while (ops.top() != '(') {
				terms.push(solve());
				}
			ops.pop();										//pops remaining open parenthesis from operand stack
		}
		else if (expression[i] == '+' || expression[i] == '-' || expression[i] == '=' || expression[i] == '&' || expression[i] == '|' || expression[i] == '!') {
			if (!specialOp(expression[i])) {				//checks for special operand cases (two-character operators)
				if (!ops.empty() && ops.top() != '(') {		// if situation is not special, check for precedence
					char op = ops.top();
					if (precedence(op) > precedence(expression[i])) { 
						terms.push(solve());				//if current i precedence is less than top of ops stack precedence, evaluate
					}										//and push result onto terms stack
				}
				ops.push(expression[i]);					//if not special or of lesser precedence, push operator to operand stack
			}
		}
		else {
			if (!ops.empty() && ops.top() != '(') {			//check for precedence
				char op = ops.top();
				if (precedence(op) > precedence(expression[i])) {  //if current i precedence is less than top of ops stack precedence, evaluate
					terms.push(solve());						   //and push result onto terms stack
				}
			}
		ops.push(expression[i]);							//if not of lesser precedence, push operator to operand stack
		}
	}
	while (!ops.empty()) {									//for all remaining elements on operand stacks after precedence
		terms.push(solve());								//checking, evaluate and push result onto stack
	}
	cout << terms.top() << '\n';							//print final stack value
	return 0;
}
int Evaluator::precedence(char o) {							//evaluate operator precedence
	switch (o) {
	case 'o':
	case '|':												//represents OR check
		return 1;
		break;
	case 'a':												//represents AND check
	case '&':
		return 2;
		break;
	case 'e':												//represents equality check
	case 'n':												//represents non-equality check	
		return 3;
		break;
	case '<':
	case '>':
	case 'l':												//represents less than or equal to check
	case 'g':												//represents greater than or equal to check
		return 4;
		break;
	case '+':
	case '-':
		return 5;
		break;
	case '*':
	case '/':
	case '%':
		return 6;
		break;
	case '^':
		return 7;
		break;
	case 'm':												//represents pre-decrement
	case 'p':												//represents pre-increment
	case 'z':												//represents negative
	case '!':												//represents NOT
		return 8;
		break;
	}
}
string Evaluator::removeSpaces(string str) {				//removes whitespace from string
	string new_str;
	for (int i = 0; i < str.length(); i++) {				//iterates through each character in string
		if (str[i] != ' ') {								//if not a whitespace character
			new_str += str[i];								//append to new string
		}
	}
	return new_str;											//return new string to use as expression for parsing
}
int Evaluator::solve() {									//evaluates expression based on operator
	int solution;

	char op = ops.top();
	ops.pop();
															//first handle single term operators
	if (op == 'p') {										//like pre-increment
		solution = uOp('+');
	}
	else if (op == 'm') {									//pre-decrement
		solution = uOp('-');
	}
	else if (op == '!') {
		solution = uOp('!');								//NOT
	}
	else if (op == 'z') {									//and negative
		solution = uOp('z');
	}
	else {													//then handle all two term operators
		int b = terms.top();
		terms.pop();

		int a = terms.top();
		terms.pop();

		switch (op) {
		case '+': solution = a + b;
			break;
		case '-': solution = a - b;
			break;
		case '*': solution = a * b;
			break;
		case '/': solution = a / b;
			break;
		case '%': solution = a % b;
			break;
		case '^': solution = pow(a, b);
			break;
		case '<': solution = (a < b);
			break;
		case 'a':
			solution = (a && b);
			break;
		case '>': solution = (a > b);
			break;
		case 'e': solution = (a == b);
			break;
		case 'l': solution = (a <= b);
			break;
		case 'n': solution = (a != b);
			break;
		case 'o': solution = (a || b);
			break;
		case 'g': solution = (a >= b);
			break;
		}
	}
	return solution;										//return expression value
}
int Evaluator::uOp(char o) {								//handles unary operators
	int x;											
	switch (o) {
	case '+': 
		x = terms.top() + 1;								//increment term on top of terms stack
		terms.pop();										//remove term on top of terms stack
		return x;											//return incremented term to later be pushed onto stack
	case '-':
		x = terms.top() - 1;
		terms.pop();
		return x;
	case '!':
		x = terms.top();
		terms.pop();
		return (!x);
	case 'z':
		x = terms.top();
		terms.pop();
		return (0 - x);
	}
}
bool Evaluator::specialOp(char o) {							//evaluates special operator functions - if needed, replaced two character operators with a single operator
	if (!ops.empty() && o == '+' && ops.top() == '+' && terms.empty()) {	//checks for second + sign for pre-increment
		ops.pop();															// removes first '+' from stack for replacement
		ops.push('p');								//pushes p to designate pre-increment - assumes pre-inc is at beginning of expression
	}
	else if (!ops.empty() && o == '+' && ops.top() == 'p' && terms.empty()) { //checks for p value to avoid early evaluation
		ops.push('+');														 //when there are two pre-inc's in a row
	}																		 //pushes + sign to continue with normal operation	
	else if (!ops.empty() && o == '-' && ops.top() == '-' && terms.empty()) { //checks for second - sign for pre-decrement
		ops.pop();															// removes first '-' from stack for replacement
		ops.push('m');								//pushes m to designate pre-decrement - assumes pre-dec is at beginning of expression
	}
	else if (!ops.empty() && o == '-' && ops.top() == '(') { //checks for second - sign for pre-decrement
		ops.push('z');								//pushes z to designate negative - assumes negative is in parenthesis
	}
	else if (!ops.empty() && o == '=' && ops.top() == '=') {				//checks for second = sign for equality check
		ops.pop();															// removes first '=' from stack for replacement
		ops.push('e');														//pushes e to designate equality check
	}
	else if (!ops.empty() && o == '=' && ops.top() == '!') {				//checks for second ! sign for non-equality check
		ops.pop();															// removes first '!' from stack for replacement
		ops.push('n');														//pushes n to designate non-equality check
	}
	else if (!ops.empty() && o == '=' && ops.top() == '<') {				//checks for < after = for less than or equal to check
		ops.pop();															// removes first '<' from stack for replacement
		ops.push('l');														//pushes l to designate less than or equal to check
	}
	else if (!ops.empty() && o == '=' && ops.top() == '>') {				//checks for > after = for greater than or equal to check
		ops.pop();															// removes first '>' from stack for replacement
		ops.push('g');														//pushes g to designate greater than or equal to check
	}
	else if (!ops.empty() && o == '&' && ops.top() == '&') {				//checks for second & sign for AND check
		ops.pop();															// removes first '&' from stack for replacement
		ops.push('a');														//pushes a to designate AND check
	}
	else if (!ops.empty() && o == '|' && ops.top() == '|') { //checks for second | sign for OR check
		ops.pop();															// removes first '|' from stack for replacement
		ops.push('o');														//pushes a to designate OR check
	}
	else {
		return false;														//return false if not special case
	}
	return true;															//return true if special
}
int Evaluator::errorCheck(string exp) {						//Lauren's Code
	string equation = exp;
	int leng_str = 0;
	leng_str = equation.length();

	// creating character array
	char expression_arr[100];

	// putting characters of string into char array
	strcpy_s(expression_arr, equation.c_str());


	//Error Check

	// Check for Divide by Zero Error
	for (int i = equation.size() - 1; i > equation.size() - 3; i--) {
		if (equation.substr(equation.size() - 2, equation.size()) == "/0") {
			cout << "Divide by Zero Error at char " << equation.size() - 2 << endl;
			return 1;
		}
	}
	if (equation.substr(0, 1) == ")") {
		cout << "Expression can't start with a closing parenthesis at char 0" << endl;
		return 1;
	}

	if (equation.substr(0, 1) == "<" || equation.substr(0, 1) == ">") {
		cout << "Expression can't start with a binary operator at char 0" << endl;
		return 1;
	}

	//Check for double binary operators error
	int oper1 = 0;
	int oper2 = 3;

	for (int i = 0; oper2 < equation.size() - 1; i++) {
		if (equation.substr(oper1, oper2) == "&&&&" || equation.substr(oper1, oper2) == "||||" || equation.substr(oper1, oper2) == "====") {
			cout << "Two Binary Operators in a row at char " << oper1 << endl;
			return 1;
		}
		oper1 += 1;
		oper2 += 1;

	}

	//Check for double operands in a row
	oper1 = 0;
	oper2 = 1;

	for (int i = 0; oper2 < equation.size(); i++) {
		if (isdigit(equation[oper1]) && isdigit(equation[oper2])) {
			cout << "Two Operands in a row at char " << oper1 << endl;
			return 1;
		}
		oper1 += 1;
		oper2 += 1;

	}

	//Check for unary operand followed by a binary operator
	oper1 = 0;
	oper2 = 2;
	for (int i = 0; oper2 < equation.size() - 1; i++) {
		if (equation.substr(oper1, oper2) == "+++" || equation.substr(oper1, oper2) == "---") {
			if (equation[oper2 + 2] == '+' || equation[oper2 + 2] == '-') {
				return 0;
			}
			else {
				cout << "Can't have a unary operator followed by a binary operator at char " << oper1 << endl;
				return 1;
			}
		}
		oper1 += 1;
		oper2 += 1;
	}
	return 0;
}
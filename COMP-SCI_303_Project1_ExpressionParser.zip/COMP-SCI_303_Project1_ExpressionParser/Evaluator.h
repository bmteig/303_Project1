#pragma once
#include <iostream>
#include <string>
#include <cstring>
#include <stack>
using namespace std;
class Evaluator												//assumes single digit terms
{
private:
	string expression;										//expression entered for parsing
	stack<int> terms;										//stack to store expression terms (integers)
	stack<char> ops;										//stack to store operands
public:
	Evaluator();
	int Evaluator::errorCheck(string exp);					//if error found, error message is printed and evaluation process is abandoned; O(n)
	string removeSpaces(string str);						//removes spaces for clean expression parsing; O(n)
	int eval(string exp);									//main parsing function; O(n)
	int precedence(char o);									//determines precedence of operators to ensure proper evaluation order; O(1)
	int Evaluator::solve();									//evaluates mathemeatical functions after parsing; O(n)
	int uOp(char o);										//evaluates unary operators in expressions (pre incremement/decrement/not); O(1)
	bool specialOp(char o);									//determines special case operands -- if needed, replaces two character
	~Evaluator();											//operands with single letter for simple parsing; O(n)
};


#include "Evaluator.h"
int main() {
	
	Evaluator eval = Evaluator();

	//Project Expressions
	eval.eval("1+2*3");
	eval.eval("2+2^2*3");
	eval.eval("1==2");
	eval.eval("1+3 > 2");
	eval.eval("(4>=4) && 0");
	eval.eval("(1+2)*3");
	eval.eval("++++2-5*(3^2)");
	//Error Expressions
	eval.eval(")3+2");
	eval.eval("<3+2");
	eval.eval("3&&&& 5");
	eval.eval("1+32");
	eval.eval("1+++3");
	eval.eval("1/0");
	//Other Expressions
	eval.eval("0 || 0");
	eval.eval("1 != 2");
	eval.eval("!0");
	eval.eval("1+2*3+5*8+4/2");
	eval.eval("5%3+2");
	eval.eval("5>=2");
	

	system("pause");
	return 0;
}